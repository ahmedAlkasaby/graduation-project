<?php

namespace App\Services\Api\Auth;

use App\Contracts\SocialTokenVerifierInterface;
use App\DTOs\AuthenticatedUserDTO;
use App\DTOs\SocialUserDTO;
use App\Enums\SocialProviderEnum;
use App\Enums\UserTypeEnum;
use App\Models\Device;
use App\Models\User;
use App\Services\Api\Auth\Social\AppleTokenVerifier;
use App\Services\Api\Auth\Social\FacebookTokenVerifier;
use App\Services\Api\Auth\Social\GoogleTokenVerifier;

class SocialLoginService
{
    public function __construct(
        private readonly TokenService $tokenService,
    ) {}

    public function login(
        SocialProviderEnum $provider,
        string $socialToken,
        string $imei,
        string $deviceToken,
        string $deviceType,
        UserTypeEnum $type = UserTypeEnum::Donor,
    ): ?AuthenticatedUserDTO {
        $socialUser = $this->verifierFor($provider)->verify($socialToken);

        if (! $socialUser instanceof SocialUserDTO) {
            return null;
        }

        $user = $this->findOrCreateUser($provider, $socialUser, $type);

        if (! $user->active) {
            return null;
        }

        Device::updateDevice($user->id, $imei, $deviceToken, $deviceType);

        return $this->tokenService->issue($user);
    }

    private function verifierFor(SocialProviderEnum $provider): SocialTokenVerifierInterface
    {
        return app(match ($provider) {
            SocialProviderEnum::Google => GoogleTokenVerifier::class,
            SocialProviderEnum::Facebook => FacebookTokenVerifier::class,
            SocialProviderEnum::Apple => AppleTokenVerifier::class,
        });
    }

    /**
     * Only app users are matched, the same as a password sign in; $type is
     * used only when the account is first created.
     */
    private function findOrCreateUser(SocialProviderEnum $provider, SocialUserDTO $socialUser, UserTypeEnum $type): User
    {
        $profile = [
            'email' => $socialUser->email,
            'full_name' => $socialUser->displayName(),
        ];

        $user = User::whereIn('type', UserTypeEnum::appValues())
            ->where('provider', $provider->value)
            ->where('provider_id', $socialUser->id)
            ->first();

        if ($user) {
            $user->update($profile);

            return $user;
        }

        return User::create($profile + [
            'provider' => $provider->value,
            'provider_id' => $socialUser->id,
            'type' => $type->value,
        ]);
    }
}
